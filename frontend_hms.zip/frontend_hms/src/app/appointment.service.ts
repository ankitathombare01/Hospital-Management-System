import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Appointment } from './appointment';

@Injectable({
  providedIn: 'root'
})
export class AppointmentService {
  private baseUrl = 'http://localhost:8080/api/appointments'; // Base URL of your backend API

  constructor(private httpClient: HttpClient) {}

  getAllAppointments(): Observable<Appointment[]> {
    return this.httpClient.get<Appointment[]>(`${this.baseUrl}/getAllAppointments`);
  }

  createAppointment(appointment: Appointment): Observable<Appointment> {
    return this.httpClient.post<Appointment>(`${this.baseUrl}/addAppointment`, appointment);
  }

  deleteAppointment(id:number):Observable<object> {
    return this.httpClient.delete(`${this.baseUrl}/appointments/${id}`);
  }

  // Other methods like updateAppointment, deleteAppointment, etc.
}
