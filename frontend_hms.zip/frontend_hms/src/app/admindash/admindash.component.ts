// admindash.component.ts

import { Component } from '@angular/core';
import { PatientService } from '../patient.service'; // Assuming PatientService is imported
import { Patient } from '../patient'; // Assuming Patient interface is imported
import { AdminauthService } from '../adminauth.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-admindash',
  templateUrl: './admindash.component.html',
  styleUrls: ['./admindash.component.css']
})
export class AdmindashComponent {

  searchText: string = "";
  patients: Patient[] = []; // Assuming Patient interface is imported

  constructor(private patientService: PatientService,private adminauthService:AdminauthService, private router:Router) {}

  ngOnInit(): void {
    this.getPatients();
  }

  private getPatients() {
    this.patientService.getAllPatients().subscribe(data => {
      this.patients = data;
    });
  }

  searchPatients() {
    if (this.searchText.trim() === '') {
      // If the search text is empty, reset to the original patient list
      this.getPatients();
    } else {
      // Filter patients based on the search text
      this.patients = this.patients.filter(patient =>
        patient.name.toLowerCase().includes(this.searchText.toLowerCase())
      );
    }
  }

  delete(id: number): void {
    this.patientService.deletePatient(id).subscribe(
      () => {
        console.log('Patient deleted successfully');
        // Optionally, update the patient list or perform other actions after deletion
        this.getPatients(); // Assuming you have a method to fetch patients
      },
      error => {
        console.error('Error deleting patient:', error);
        // Handle errors if any
      }
    );
  }

  logout() {
    // Implement logout logic here
    this.adminauthService.logout();
    this.router.navigate(['home'])
    console.log('Logout button clicked');
    // Example: Redirect to login page or clear authentication token
  }
}
