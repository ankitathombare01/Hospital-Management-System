// appointment.ts

export class Appointment {
    id:number=0;
    name:string="";
    age:number=0;
    symptoms: string = ""; 
    number: string = ""; 
}
  